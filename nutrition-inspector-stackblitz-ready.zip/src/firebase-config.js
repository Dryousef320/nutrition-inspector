// 👇 أضف بيانات Firebase الخاصة بك هنا لاحقاً
export const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};